import React from 'react';

const MovieContext = React.createContext(null);

export default MovieContext;
