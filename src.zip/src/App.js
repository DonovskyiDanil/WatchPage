import React, { Component } from 'react';
import WatchHeader from './components/WatchHeader';
import WatchSideBar from './components/WatchSideBar';
import WatchList from './components/WatchList';
import MovieContext from './contexts/MovieContext';
import './App.css';

export default class App extends Component {
    state = {
        movies: [
            { id: 1, title: 'Movie 44', director: 'Director 1', imageUrl: 'url_to_image_1', isDone: false },
            { id: 2, title: 'Movie 33', director: 'Director 2', imageUrl: 'url_to_image_2', isDone: false },
            { id: 3, title: 'Movie 3', director: 'Director 3', imageUrl: 'url_to_image_3', isDone: false },
            { id: 4, title: 'Movie 4', director: 'Director 4', imageUrl: 'url_to_image_4', isDone: false },
            { id: 5, title: 'Movie 5', director: 'Director 5', imageUrl: 'url_to_image_5', isDone: false }
        ],
        selectedMovieId: 1,
        newMovieTitle: '',
        newMovieDirector: '',
        newMovieImageUrl: ''
    };

    handleInputChange = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    };

    handleSubmit = (event) => {
        event.preventDefault();
        const newMovie = {
            id: this.state.movies.length + 1,
            title: this.state.newMovieTitle,
            director: this.state.newMovieDirector,
            imageUrl: this.state.newMovieImageUrl,
            isDone: false
        };
        this.setState(prevState => ({
            movies: [...prevState.movies, newMovie],
            newMovieTitle: '',
            newMovieDirector: '',
            newMovieImageUrl: ''
        }));
    };

    handleToggle = (id) => {
        this.setState(prevState => ({
            movies: prevState.movies.map(movie =>
                movie.id === id ? { ...movie, isDone: !movie.isDone } : movie
            )
        }));
    };

    handleSelectMovie = (id) => {
        this.setState({ selectedMovieId: id });
    };

    render() {
        const selectedMovie = this.state.movies.find(movie => movie.id === this.state.selectedMovieId);

        return (
            <MovieContext.Provider value={{ movies: this.state.movies, selectedMovie }}>
                <div className="frame">
                    <WatchHeader />
                    <WatchSideBar />
                    <WatchList
                        movies={this.state.movies}
                        onToggle={this.handleToggle}
                        onSelectMovie={this.handleSelectMovie}
                        newMovieTitle={this.state.newMovieTitle}
                        newMovieDirector={this.state.newMovieDirector}
                        handleInputChange={this.handleInputChange}
                        handleSubmit={this.handleSubmit}
                    />
                </div>
            </MovieContext.Provider>
        );
    }
}
